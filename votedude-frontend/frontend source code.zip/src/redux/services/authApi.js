import { api } from "./api";

export const authApi = api.injectEndpoints({
  endpoints: (builder) => ({
    register: builder.mutation({
      query: (data) => ({
        url: "/register",
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["User"],
    }),

    login: builder.mutation({
      query: (data) => ({
        url: "/login",
        method: "GET",
        body: data,
      }),
      invalidatesTags: ["User"],
    }),

    googleLogin: builder.mutation({
      query: (token) => ({
        url: "/google",
        method: "POST",
        body: {
          token,
        },
      }),
      invalidatesTags: ["User"],
    }),

    getMe: builder.query({
      query: () => "/me",
      providesTags: ["User"],
    }),

    getProfile: builder.query({
      query: (id) => `/profile/${id}`,
      providesTags: ["User"],
    }),

    updateProfile: builder.mutation({
      query: (data) => ({
        url: "/profile",
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["User"],
    }),

    logout: builder.mutation({
      query: () => ({
        url: "/logout",
        method: "POST",
      }),
      invalidatesTags: ["User"],
    }),
  }),
});

export const {
  useRegisterMutation,
  useLoginMutation,
  useGoogleLoginMutation,
  useGetMeQuery,
  useGetProfileQuery,
  useUpdateProfileMutation,
  useLogoutMutation,
} = authApi;
